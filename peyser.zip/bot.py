import requests
import json
from datetime import datetime
import time
from bs4 import BeautifulSoup
from colorthief import ColorThief
from io import BytesIO

with open("config.json", "r") as config_file:
    config = json.load(config_file)

WEBHOOK_URL = config["WEBHOOK_URL"]
API_KEY = config["API_KEY"]

last_battle_times = {}

def read_ids(file_name="ids.txt"):
    try:
        with open(file_name, "r") as file:
            return file.read().splitlines()
    except FileNotFoundError:
        return []

def battlelog(player_id):
    url = f"https://api.brawlstars.com/v1/players/%23{player_id}/battlelog"
    resp = requests.get(url, headers={"Authorization": API_KEY})
    if resp.status_code == 404:
        return True, None
    else:
        return False, resp.json()

def get_player_info(player_id):
    url = f"https://api.brawlstars.com/v1/players/%23{player_id}"
    resp = requests.get(url, headers={"Authorization": API_KEY})
    if resp.status_code == 404:
        return True, None
    else:
        player_data = resp.json()
        name = player_data.get("name", "Unknown")
        trophies = player_data.get("trophies", 0)
        return False, {"name": name, "trophies": trophies}

def get_brawlify_name(player_id):
    try:
        url = f"https://brawlify.com/stats/profile/{player_id}"
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")
        title = soup.find("title").text.split("#")[0]

        if "Something went wrong" in title:
            return "Geçersiz"
        return title.strip()
    except:
        return "Bilinmeyen"

def get_brawlify_profile_image(player_id):
    try:
        url = f"https://brawlify.com/stats/profile/{player_id}"
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")
        img_tag = soup.find("img", class_="profile-ico")

        if img_tag:
            return img_tag["src"]
        return "https://cdn.brawlify.com/profile-icons/regular/28000000.png"
    except:
        return "https://cdn.brawlify.com/profile-icons/regular/28000000.png"

def get_dominant_color(image_url):
    try:
        response = requests.get(image_url)
        color_thief = ColorThief(BytesIO(response.content))
        dominant_color = color_thief.get_color(quality=1)
        return int(f"0x{dominant_color[0]:02x}{dominant_color[1]:02x}{dominant_color[2]:02x}", 16)
    except:
        return 0xFFFFFF 

def send_webhook_embed(embed_data):
    data = {"embeds": [embed_data]}
    headers = {"Content-Type": "application/json"}
    response = requests.post(WEBHOOK_URL, json=data, headers=headers)
    
    if response.status_code == 204:
        print("Webhook gönderildi! ✅")
    else:
        print(f"Webhook gönderilemedi! ❌ Hata Kodu: {response.status_code}")

def create_battle_embed(player_id, player_name, trophies, brawler_name, brawler_power, brawler_trophies, event_mode):
    profile_image = get_brawlify_profile_image(player_id)
    dominant_color = get_dominant_color(profile_image)

    embed = {
        "title": f"{player_name} New battle detected!",
        "color": dominant_color,
        "timestamp": datetime.utcnow().isoformat(),
        "thumbnail": {"url": profile_image}, 
        "fields": [
            {"name": "Player ID", "value": f"#{player_id}", "inline": True},
            {"name": "Player Nick", "value": player_name, "inline": True},
            {"name": "Trophies", "value": f"{trophies} 🏆", "inline": True},
            {"name": "Brawler", "value": brawler_name, "inline": True},
            {"name": "Level", "value": f"Power {brawler_power}", "inline": True},
            {"name": "Brawler Trophies", "value": f"{brawler_trophies} 🏆", "inline": True},
            {"name": "Event", "value": event_mode, "inline": True}
        ]
    }
    return embed

def check_all_players():
    global last_battle_times

    ids = read_ids()
    for player_id in ids:
        hata, log = battlelog(player_id)
        if hata or not log.get('items'):
            print(f"#{player_id} -- Battlelog not found! ⚠️")
            continue

        last_battle = log['items'][0]
        battle_time = last_battle.get('battleTime')

        if battle_time and (player_id not in last_battle_times or battle_time != last_battle_times[player_id]):
            if player_id not in last_battle_times:
                last_battle_times[player_id] = battle_time
                print(f"Skipping initial match for #{player_id}.") 
                continue

            last_battle_times[player_id] = battle_time  

            event_mode = last_battle['event'].get('mode', 'Unknown')
            teams = last_battle['battle'].get('teams', [])

            
            player_data = None
            for team in teams:
                for player in team:
                    if player['tag'][1:] == player_id:
                        player_data = player
                        break
                if player_data:
                    break

            if player_data:
                brawler = player_data['brawler']
                brawler_name = brawler['name']
                brawler_power = brawler['power']
                brawler_trophies = brawler['trophies']

                hata, player_info = get_player_info(player_id)
                if not hata:
                    player_name = get_brawlify_name(player_id)
                    trophies = player_info.get("trophies", 0)

                    embed = create_battle_embed(player_id, player_name, trophies, brawler_name, brawler_power, brawler_trophies, event_mode)
                    send_webhook_embed(embed)

if __name__ == "__main__":
    print("Webhook battle tracker... ✅")
    while True:
        check_all_players()
        time.sleep(10)
